# Batch 1: Strategic Automation Leadership

A workshop for managers, department heads, process owners, and contributing knowledge workers to explore Power Automate, select a worthwhile improvement, and explain a workflow proposal to their teams. Each group should include someone who can explain the current process and take ownership of the next decision.

**Your outputs:** one selected opportunity, one physical Flow-card draft, one improved flipchart flow map, and one Leadership Handover Card presented to the workshop.

## Learning objectives

By the end of the workshop, you can:

1. Explain a suitable Power Automate use, an important boundary, and a decision that remains with a person.
2. Map a current process with 5–8 steps, roles, handovers, and evidence-linked friction.
3. Screen three opportunities for readiness and justify one manageable candidate.
4. Define a Workflow Blueprint using a Trigger, Actions, Conditions where needed, human checkpoints, and owned exception routes.
5. Redraw the Flow-card idea as a clear, free-form map and prepare a safe photo for review.
6. Use a preferred Generative AI tool as a second reader, then decide which feedback improves the map.
7. Produce and present a Leadership Handover Card with scope, owner, expected benefit, unresolved checks, next decision, and follow-up date.

## Course structure

- **3 Modules:** Demystifying Power Automate; Unlocking Operational Bottlenecks; Strategic Workflow Blueprinting.
- **4 Delivery blocks:** the four fixed teaching windows around breaks and lunch.
- **5 Exercises:** the linked learner activities below.
- **Practices:** focused activities, each with one named output and checkpoint.

## Before you begin

- No prior Power Automate building experience is required.
- Complete the pre-workshop survey when provided. The facilitator will connect available findings to the opening discussion. If findings are unavailable, use the fictional training-request case.
- Be ready to describe one repetitive process at a non-confidential level, or use the supplied fictional case.
- Work in groups of 4–6, adjusted to the room. Exercise 1 uses two flipchart sheets, one blank A4 sheet, six scenario sticky notes, five sticky notes per participant, and pens or pencils. The facilitator supplies physical Flow cards separately for later exercises.
- Exercise 1 needs no participant computer, account, download, or opened file. Follow the projected prompts and the facilitator's spoken instructions.
- Paper activities require no Power Automate account or paid Power Automate licence. You will not build or deploy a flow.
- For the final review, each group may use any available image-capable Generative AI tool, such as ChatGPT, Gemini, Claude, or Copilot.
- Use only the supplied fictional case or a sanitised process map. Before upload, remove personal, customer, confidential, unauthorised operational, and identifying visual information from the photo.
- If internet access, an account, or image upload is unavailable, use the facilitator-led review questions in Exercise 5.

## Fixed timetable

| Time | Delivery block | Learning focus |
|---|---|---|
| 09:00–10:30 | Block 1 | Demystifying Power Automate |
| 10:30–10:45 | Break | |
| 10:45–12:00 | Block 2 | Complete Demystifying Power Automate; begin Unlocking Operational Bottlenecks |
| 12:00–13:00 | Lunch | |
| 13:00–14:30 | Block 3 | Select a bottleneck; begin Strategic Workflow Blueprinting |
| 14:30–14:45 | Break | |
| 14:45–16:00 | Block 4 | Draw, photograph, improve, hand over, and present the workflow idea |

Teaching time is 330 minutes. Each of the three topics has 110 minutes. Topic transitions are at 11:05 and 13:55. Pre/post assessments remain outside teaching time.

## Exercises

1. [Benefits and boundaries](exercises/01-understand-automation/README.md): 09:30–10:10 and 10:45–11:05.
2. [Map work and friction](exercises/02-map-work-friction/README.md): 11:15–11:55.
3. [Select an opportunity](exercises/03-prioritize-opportunity/README.md): 13:10–13:50.
4. [Design with physical Flow cards](exercises/04-workflow-blueprint/README.md): 13:50–14:30, including the concept explanation.
5. [Improve and present the workflow idea](exercises/05-leadership-handover/README.md): 14:45–15:57.

Use 15:57–16:00 for your exit reflection. Explanations, Q&A, and checkpoints fill the remaining teaching windows.

## Learning materials

- [Optional fictional case pack and scenario reference](files/case-pack.md)
- [Worksheets for Exercises 2–5](files/worksheets.md)
- [40-slide English PowerPoint](presentations/strategic-automation-leadership-en-revised-v4.pptx)
- [Presentation outline](presentation-outline.md)

The supplied Flow-card PDF and images are not part of this digital package. The card arrangement, flipchart map, Generative AI feedback, and facilitator review do not prove technical feasibility or readiness for deployment.

## Official references

- [Power Automate triggers](https://learn.microsoft.com/en-us/power-automate/triggers-introduction)
